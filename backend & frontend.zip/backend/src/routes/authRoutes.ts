import express, { Request, Response, NextFunction } from 'express';
import { registerUser, loginUser } from '../controllers/authController';

const router = express.Router();

// Async wrapper som hanterar fel i async-funktioner
const asyncHandler = (fn: Function) => (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    Promise.resolve(fn(req, res, next)).catch(next);
};

router.post('/register', asyncHandler(registerUser));
router.post('/login', asyncHandler(loginUser));

export default router;
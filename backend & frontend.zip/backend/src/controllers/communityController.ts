import { Request, Response } from 'express';
import pool from '../models/UserModel';

export const createCommunity = async (req: Request, res: Response) => {
    const { name, description } = req.body;

    if (!name) return res.status(400).json({ message: 'Namn krävs' });

    try {
        const result = await pool.query(
            `INSERT INTO communities (name, description) 
            VALUES ($1, $2) RETURNING *`,
            [name, description]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Fel vid skapande av community' });
    }
};

export const joinCommunityController = async (req: Request, res: Response) => {
    const { userId } = req.body;
    const { communityId } = req.params;

    try {
        await pool.query(
            `INSERT INTO user_communities (user_id, community_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
            [userId, communityId]
        );
        res.status(200).json({ message: 'Du gick med i communityt!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Fel vid join community' });
    }
};
